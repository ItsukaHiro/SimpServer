# Resource Pack cho SimpServer
Uh thì đây là cái resource pack được làm cho một cái server của mấy thằng Simp Vtuber thôi

Server Address: Hidden

[Wiki](https://github.com/ItsukaHiro/SimpServer/wiki) - Bao gồm các thông tin vể server và các bài hướng dẫn được dàn devs viết.
